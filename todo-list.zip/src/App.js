import './App.css';
// import TodoList from './TodoList';
// import NewTodoList from './NewTodoList';
import TodoApp from './TodoApp';

function App() {
  return (
    <>
    {/* <TodoList /> */}
    {/* <NewTodoList /> */}
    <TodoApp />
    </>
  );
}

export default App;
